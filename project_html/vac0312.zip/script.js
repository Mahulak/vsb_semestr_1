        function zmenBarvy() {
            var blokObsah = document.querySelector(".obsah");
            blokObsah.classList.toggle("svetly-rezim");
        }
        function vyskocAlert() {
            alert("Ahoj! Vítej na mé stránce!");
        }